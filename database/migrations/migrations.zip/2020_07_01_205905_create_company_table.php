<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCompanyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('companies', function (Blueprint $table) 
        {
            $table->id();
            $table->string('company_name');
            $table->string('company_com_record');
            $table->date('company_issue_date');
            $table->unsignedBigInteger('company_country');
            $table->foreign('company_country')->references('id')->on('countries');
            $table->unsignedBigInteger('company_city');
            $table->foreign('company_city')->references('id')->on('cities');
            $table->string('company_street');
            $table->string('company_building');
            $table->string('company_email');
            $table->string('company_mobile');
            $table->integer('status')->default(1);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('companies');
    }
}
