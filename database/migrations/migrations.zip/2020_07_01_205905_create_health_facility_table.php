<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatehealthFacilityTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('health_facility', function (Blueprint $table) 
        {
            $table->id();
            $table->string('health_name');
            $table->unsignedBigInteger('health_class');
            $table->unsignedBigInteger('health_specialty');
            $table->string('health_com_record');
            $table->date('health_issue_date');
            $table->date('health_exp_date');
            $table->unsignedBigInteger('health_country');
            $table->foreign('health_country')->references('id')->on('countries');
            $table->unsignedBigInteger('health_city');
            $table->foreign('health_city')->references('id')->on('cities');
            $table->string('health_street');
            $table->string('health_building');
            $table->string('health_email');
            $table->string('health_mobile');
            $table->integer('status')->default(1);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('health_facility');
    }
}
